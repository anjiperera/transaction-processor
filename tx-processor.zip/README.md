Thanks for taking the time to look at Barrenjoey Markets Technology java assessment.

In the package com.barrenjoey.java.bank you will find a hopefully interesting and open exercise. 
Simulating a situation where you are thrown in the deep end without perhaps as much information as you would like.
Please don't be discouraged, use your experience to make some engineering decisions and interpret the requirements
as best you can.

You will find a README file in the  package with more information. Good luck!

## Requirements

1. Read the transaction files in order and updates the internal accounts according to the account entries. 
2. Transaction files should be processed as soon as possible without a delay.
3. Clients should be able to query the bank accounts by id at any time and the bank accounts should be in a consistent 
state (i.e., balance is the sum of the account entries). 
4. Each account activity must be reported to a 3rd party reporting service.

## High-level Design

Below figure shows a high-level design of the system. 

<img src="figures/tx-processor-design.png" />

The system has three services (Transaction Reader, Transaction Processor and Transaction Reporter) and one Controller 
(Client Input Handler) that can be run independent of each other (i.e., in different threads). 

### Transaction Reader 
This is responsible for reading account entries from the input file the client provided **in order**. 
The account entries are added to `Entry Queues` to be processed by the Transaction Processor service. 
Since, we want to maintain the order of the account entries, the Transaction Reader service must be run in a single thread. 

Each entry queue is consumed by an instance of a Transaction Processor service. 
Transaction Reader service ensures all account entries of a bank account always go to the same entry queue in the order 
they are read from the file. 

### Transaction Processor

This is responsible for processing the account entries from the `Entry Queue`. 
It updates the bank accounts according to account entries, generates transaction reports and sends them to the 
`Report Queue` to be processed by the Transaction Reporter service. 

To speed up the process, multiple Transaction Processors can be run in multiple threads. 
Each Transaction Processor instance is assigned a separate entry queue. 
Each bank account is always updated by a single Transaction Processor instance for the duration of the application. 
Hence, there is no possibility of concurrent modifications by multiple Transaction Processors. 

### Transaction Reporter

This is responsible for reporting the transactions from the `Report Queue` to the legacy reporting server. 
Since, the Reporting Server is able to handle multiple concurrent clients, multiple Transaction Reporters can be run in 
multiple threads to speed up the process. 

### Client Input Handler

This is a simple mock up to demonstrate the ability of the system to continuously read client requests for bank accounts
(by their ids) and respond with the corresponding bank accounts in a consistent state. 

## Using

### System Requirements

- Java (`>= 17`)
- Gradle (`>= 7.4`)

### Running Tests

```bash
./gradlew test
```

### Running the Application

The application will run with 4 threads at minimum, i.e., one each for each service and the controller. 
Additionally, you can configure TransactionProcessor and TransactionReporter services to run in multiple threads. 

Below are the configurations of the application. 
The run commands below give examples for each configuration. 
A simple `Driver` class is included to read the configs as command-line arguments, create the instances of services and 
controller, and run the application. 

1. `d` or `tx-dir` - Path to the directory containing the input transaction log files. 
2. `f` or `tx-prefix` - Prefix of the transaction log file name
3. `e` or `entry-q-size` - Maximum capacity of an entry queue `(> 0)`
4. `t` or `report-q-size` - Maximum capacity of the report queue `(> 0)`
5. `p` or `n-threads-processor` - Number of threads for the Transaction Processor service `(> 0)`
6. `r` or `n-threads-reporter` - Number of threads for the Transaction Reporter service `(> 0)`

```text
Producers of each queue will wait indefinitely if the queue reaches the full capacity and only proceeds when at least 
one spot becomes available in the queue. 
This ensures account entries and transaction reports are not lost in the case of queues reaching max capacities. 

In general, you can allocate higher max capacity for the report queue if you are running the Transaction Reporter in a 
single thread. 
On the other hand, if you are running multiple Transaction Reporter threads, then the max capacity for the report queue 
can be lower. 
Same can be applied to the Transaction Processor service and entry queue. Although the bottleneck is mostly in the 
Transaction Reporter service caused by the legacy reporting server. 
```

#### Running with the Jar Provided

```bash
java -jar tx-processor.jar -d=src/main/resources -f=transaction-log. -e=50000 -t=100000 -p=2 -r=4
```

#### If you are changing the code and running

```bash
./gradlew shadowJar
java -jar build/libs/tx-processor-1.0-SNAPSHOT-all.jar -d=src/main/resources -f=transaction-log. -e=50000 -t=100000 -p=2 -r=4
```

Each service (i.e., threads) will stop once they have finished their job. However, the controller (Client Input Handler)
will keep running until the client requests to terminate it. 