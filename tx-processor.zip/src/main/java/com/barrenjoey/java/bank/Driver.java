package com.barrenjoey.java.bank;

import com.barrenjoey.java.bank.external.ReportingServer;
import com.barrenjoey.java.bank.model.AccountEntry;
import com.barrenjoey.java.bank.model.Bank;
import com.barrenjoey.java.bank.model.BankImpl;
import com.barrenjoey.java.bank.controllers.ClientInputHandler;
import com.barrenjoey.java.bank.services.TransactionProcessor;
import com.barrenjoey.java.bank.services.TransactionReader;
import com.barrenjoey.java.bank.external.LegacyReportingServer;
import com.barrenjoey.java.bank.services.TransactionReporter;
import com.barrenjoey.java.bank.model.TransactionReport;
import org.apache.commons.cli.*;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.*;

/**
 * A simple Driver class responsible for running the application (i.e., three services and controller)
 */
public class Driver {

    public static void main(String[] args) {
        // Read command-line options
        Options options = DriverOptions.get();
        CommandLineParser parser = new DefaultParser();
        HelpFormatter formatter = new HelpFormatter();

        final String txFilesDir;
        final String txFilePrefix;
        final int entryQueueSize;
        final int reportQueueSize;
        final int numProcessors;
        final int numReporters;

        try {
            CommandLine cmd = parser.parse(options, args);

            if (cmd.hasOption("h")) {
                formatter.printHelp("AussieBank", options);
                return;
            }

            if (cmd.hasOption("d")) {
                txFilesDir = cmd.getOptionValue("d");
            } else {
                printMissingArg("d", formatter, options);
                return;
            }

            if (cmd.hasOption("f")) {
                txFilePrefix = cmd.getOptionValue("f");
            } else {
                printMissingArg("f", formatter, options);
                return;
            }

            if (cmd.hasOption("e")) {
                entryQueueSize = Integer.parseInt(cmd.getOptionValue("e"));
            } else {
                printMissingArg("e", formatter, options);
                return;
            }

            if (cmd.hasOption("t")) {
                reportQueueSize = Integer.parseInt(cmd.getOptionValue("t"));
            } else {
                printMissingArg("t", formatter, options);
                return;
            }

            if (cmd.hasOption("p")) {
                numProcessors = Integer.parseInt(cmd.getOptionValue("p"));
            } else {
                printMissingArg("p", formatter, options);
                return;
            }

            if (cmd.hasOption("r")) {
                numReporters = Integer.parseInt(cmd.getOptionValue("r"));
            } else {
                printMissingArg("r", formatter, options);
                return;
            }
        } catch (ParseException | NumberFormatException e) {
            System.out.printf("Error parsing cmd line options: %s\n", e.getMessage());
            formatter.printHelp("AussieBank", options);
            return;
        }

        // Setup and Run the Application
        int totalThreads = numProcessors + numReporters + 2;
        ExecutorService executorService = Executors.newFixedThreadPool(totalThreads);

        // Bank instance
        Bank bank = new BankImpl();

        // Entry Queues
        Map<Integer, BlockingQueue<AccountEntry>> entryQueues = new HashMap<>();
        for (int pId = 0; pId < numProcessors; pId++) {
            entryQueues.put(pId, new LinkedBlockingQueue<>(entryQueueSize));
        }

        // Report Queue
        BlockingQueue<TransactionReport> reportQueue = new LinkedBlockingQueue<>(reportQueueSize);

        // Reporting Server
        ReportingServer reportingServer = new LegacyReportingServer();

        // Submit the service and controller instances to the executor service
        executorService.submit(new TransactionReader(entryQueues, txFilesDir, txFilePrefix));

        // Create a countdown latch to be shared between the TransactionProcessors and TransactionReporters
        CountDownLatch sharedLatch = new CountDownLatch(numProcessors);
        for (int pId = 0; pId < numProcessors; pId++) {
            executorService.submit(new TransactionProcessor(entryQueues.get(pId), bank, reportQueue, sharedLatch));
        }

        for (int rId = 0; rId < numReporters; rId++) {
            executorService.submit(new TransactionReporter(reportQueue, reportingServer, sharedLatch));
        }

        executorService.submit(new ClientInputHandler(bank));

        executorService.shutdown();
    }

    private static void printMissingArg(String arg, HelpFormatter formatter, Options options) {
        System.out.printf("Argument %s is missing.\n", arg);
        formatter.printHelp("AussieBank", options);
    }
 }
