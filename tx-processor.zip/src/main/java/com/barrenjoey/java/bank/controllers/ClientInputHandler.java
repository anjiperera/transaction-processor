package com.barrenjoey.java.bank.controllers;

import com.barrenjoey.java.bank.model.BankAccount;
import com.barrenjoey.java.bank.model.Bank;

import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 * A simple mock up to handle client requests to retrieve bank accounts by id
 */
public class ClientInputHandler implements Runnable {

    Bank bank;
    Scanner scanner;

    public ClientInputHandler(Bank bank) {
        this.bank = bank;
        this.scanner = new Scanner(System.in);
    }

    /**
     * Executes until the {@code handleClientInput()} method signals to terminate
     */
    @Override
    public void run() {
        System.out.println("Welcome to AussieBank Client Interface!");
        while (true) {
            if (handleClientInput() > 0) break;
        }

        System.out.println("Closing the Client Interface.");
        scanner.close();
    }

    /**
     * Waits for the client input via stdin and displays the requested bank account
     * @return {@code > 0} if the client requested to exit or {@code 0} if otherwise
     */
    private int handleClientInput() {
        System.out.print("Enter account id (or 0 to exit): ");
        String userInput = scanner.nextLine();

        if ("".equals(userInput)) return 0;

        if ("0".equals(userInput)) return 1;

        int accountId;
        try {
            accountId = Integer.parseInt(userInput);
        } catch (NumberFormatException e) {
            System.out.println("Please enter a valid number.");
            return 0;
        }

        BankAccount account;
        try {
            account = bank.getAccountById(accountId);
        } catch (NoSuchElementException e) {
            System.out.printf("There is no bank account with the id %d%n", accountId);
            return 0;
        }

        System.out.println(account != null ? account.toString() :
                String.format("There is no bank account with the id %d", accountId));
        return 0;
    }
}
