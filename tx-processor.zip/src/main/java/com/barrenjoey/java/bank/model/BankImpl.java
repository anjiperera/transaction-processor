package com.barrenjoey.java.bank.model;

import java.util.NoSuchElementException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class BankImpl implements Bank {

    /**
     * ConcurrentMap is used since multiple threads can modify the accounts map at the same time
     */
    private ConcurrentMap<Integer, BankAccount> accounts;

    public BankImpl() {
        this.accounts = new ConcurrentHashMap<>();
    }

    @Override
    public BankAccount getAccountById(int accountId) throws NoSuchElementException {
        if (accounts.containsKey(accountId)) {
            return accounts.get(accountId).clone();
        } else {
            throw new NoSuchElementException(String.format("An account does not exist for account id %d", accountId));
        }
    }

    @Override
    public BankAccount getOrCreateAccount(int accountId) {
        if (!accounts.containsKey(accountId)) {
            accounts.put(accountId, new BankAccountImpl(accountId, 0.0));
        }
        return accounts.get(accountId);
    }
}
