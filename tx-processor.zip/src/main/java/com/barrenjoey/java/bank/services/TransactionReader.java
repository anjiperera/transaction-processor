package com.barrenjoey.java.bank.services;

import com.barrenjoey.java.bank.model.AccountEntry;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.BlockingQueue;

/**
 * This class is responsible for reading account entries from the input file the client provided in order.
 */
public class TransactionReader implements Runnable {

    private static final Logger logger = LoggerFactory.getLogger(TransactionReader.class);

    /**
     * A map of account entry queues. Each queue will be consumed by a separate thread. All the account entries of an
     * account should be pushed to a single queue
     */
    private Map<Integer, BlockingQueue<AccountEntry>> queues;
    /**
     * The path to the directory containing the transaction files
     */
    private Path txFilesDir;
    /**
     * The prefix of the transaction log files
     */
    private String txFilePrefix;

    public TransactionReader(Map<Integer, BlockingQueue<AccountEntry>> queues,
                             String txFilesDir,
                             String txFilePrefix) {
        this.queues = queues;
        this.txFilesDir = Paths.get(txFilesDir);
        this.txFilePrefix = txFilePrefix;
    }

    @Override
    public void run() {
        logger.info("Started");
        try {
            readTransactions();
        } catch (IOException | InterruptedException e) {
            logger.error("Terminating with an error");
        } finally {
            pushEOQTokens();
        }
        logger.info("Finished");
    }

    /**
     * Read transactions, i.e., account entries, in order
     */
    private void readTransactions() throws IOException, InterruptedException {
        for (long id = 1; id <= countFiles(txFilesDir, txFilePrefix); id++) {
            readEntries(txFilesDir.resolve(String.format("%s%d.csv", txFilePrefix, id)).toString());
        }
    }

    /**
     * Count the number of transaction log files with {@code prefix} in the {@code dir}
     * @param dir The path to the directory containing the transaction files
     * @param prefix The prefix of the transaction log files
     * @return The number of transaction log files
     */
    private long countFiles(Path dir, String prefix) throws IOException {
        try {
            return Files.list(dir).filter(path -> path.getFileName().toString().startsWith(prefix)).count();
        } catch (IOException e) {
            logger.error("Could not open the directory {}", dir);
            throw e;
        }
    }

    /**
     * Read account entries from a csv file
     * @param filePath Path of the transactions log file
     */
    private void readEntries(String filePath) throws IOException, InterruptedException {
        try (Reader reader = new FileReader(filePath)) {
            Iterable<CSVRecord> records = CSVFormat.DEFAULT.builder()
                    .setHeader("Acc Id", "Action", "Amount")
                    .setSkipHeaderRecord(true)
                    .build()
                    .parse(reader);

            for (CSVRecord record : records) {
                int accountId = Integer.parseInt(record.get("Acc Id"));
                AccountEntry.Action action = AccountEntry.Action.valueOf(record.get("Action").toUpperCase());
                double amount = Double.parseDouble(record.get("Amount"));
                addToQueue(accountId, new AccountEntry(accountId, action, amount, Instant.now()));
            }
        } catch (IOException e) {
            logger.error("Could not read the file at {}", filePath);
            throw e;
        }
    }

    /**
     * Push the account entry to the appropriate queue
     * @param accountId
     * @param entry
     */
    private void addToQueue(int accountId, AccountEntry entry) throws InterruptedException {
        try {
            queues.get(getQueueId(accountId)).put(entry);
        } catch (InterruptedException e) {
            logger.error("Thread was interrupted while waiting to add account entries");
            Thread.currentThread().interrupt();
            throw e;
        }
    }

    /**
     * Retrieve the id of the queue the account entries with the {@code accountId} should be pushed. This method should
     * always give a consistent queue id for each account id.
     * @param accountId
     * @return id of the queue
     */
    private int getQueueId(int accountId) {
        // since number of consumers (= number of queues) does not change during the runtime, we can use modular hashing
        int numQueues = queues.size();
        return accountId % numQueues;
    }

    /**
     * Push end of queue tokens to each queue to signal the consumer the end of the queue
     */
    private void pushEOQTokens() {
        queues.values().forEach(queue -> {
            try {
                queue.put(AccountEntry.EOQ_TOKEN);
            } catch (InterruptedException e) {
                logger.error("Thread was interrupted while waiting to add EOQ tokens");
                Thread.currentThread().interrupt();
            }
        });
    }
}
