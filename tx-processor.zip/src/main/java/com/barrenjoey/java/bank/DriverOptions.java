package com.barrenjoey.java.bank;

import org.apache.commons.cli.*;

public class DriverOptions {

    static Options get() {
        Options options = new Options();

        options.addOption("d", "tx-dir", true, "Path to the directory containing input transaction logs");
        options.addOption("f", "tx-prefix", true, "Prefix of the transaction log file name");
        options.addOption("e", "entry-q-size", true, "Maximum capacity of an entry queue");
        options.addOption("t", "report-q-size", true, "Maximum capacity of the report queue");
        options.addOption("p", "n-threads-processor", true, "Number of threads for the Transaction Processor service");
        options.addOption("r", "n-threads-reporter", true, "Number of threads for the Transaction Reporter service");
        options.addOption("h", "help", false, "Help");

        return options;
    }
}