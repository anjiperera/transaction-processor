package com.barrenjoey.java.bank.model;

import java.util.ArrayList;
import java.util.List;

public class BankAccountImpl implements BankAccount {

    private final int accountId;
    private double balance;
    private List<AccountEntry> entries;

    public BankAccountImpl(int accountId, double startingBalance) {
        this.accountId = accountId;
        this.balance = startingBalance;
        this.entries = new ArrayList<>();
    }

    @Override
    public synchronized void updateAccount(double newBalance, AccountEntry newEntry) {
        this.balance = newBalance;
        entries.add(newEntry);
    }

    /**
     * Calculate the new (updated) balance
     * @param deltaAmount
     * @return new balance
     */
    private double apply(double deltaAmount) {
        return balance + deltaAmount;
    }

    @Override
    public double deposit(double depositAmount) throws IllegalArgumentException {
        if(depositAmount < 0) throw new IllegalArgumentException("depositAmount must be positive");
        return apply(depositAmount);
    }

    @Override
    public double withdraw(double withdrawalAmount) throws IllegalArgumentException {
        if(withdrawalAmount < 0) throw new IllegalArgumentException("withdrawalAmount must be positive");
        return apply(-withdrawalAmount);
    }

    @Override
    public double getBalance() {
        return balance;
    }

    @Override
    public AccountEntry[] entries() {
        return entries.toArray(new AccountEntry[0]);
    }

    @Override
    public String toString() {
        StringBuilder accountDesc = new StringBuilder(60);
        accountDesc.append(String.format("Bank Account [Account ID: %d, Balance: %.2f]\n", accountId, balance));
        accountDesc.append("[Account Entries]\n");
        entries.forEach(entry -> accountDesc.append(entry).append("\n"));
        return accountDesc.toString();
    }

    @Override
    public synchronized BankAccountImpl clone() {
        BankAccountImpl cloned;
        try {
            cloned = (BankAccountImpl) super.clone();
        } catch (CloneNotSupportedException e) {
            cloned = new BankAccountImpl(this.accountId, this.balance);
        }

        cloned.entries = new ArrayList<>(this.entries);
        return cloned;
    }
}
