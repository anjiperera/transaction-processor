package com.barrenjoey.java.bank.services;

import com.barrenjoey.java.bank.model.TransactionReport;
import com.barrenjoey.java.bank.external.ReportingServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * This class is responsible for reporting the transactions from the Report Queue to the legacy reporting server.
 */
public class TransactionReporter implements Runnable {

    private static final Logger logger = LoggerFactory.getLogger(TransactionReporter.class);

    /**
     * Input queue with transaction reports
     */
    private BlockingQueue<TransactionReport> reportQueue;
    /**
     * Outgoing reporting server
     */
    private ReportingServer reportingServer;
    /**
     * A shared {@code CountDownLatch} to indicate the end of the {@code TransactionProcessor} instances to
     * {@code TransactionReporters}
     */
    private CountDownLatch countDownLatch;

    public TransactionReporter(BlockingQueue<TransactionReport> reportQueue,
                               ReportingServer reportingServer,
                               CountDownLatch countDownLatch) {
        this.reportQueue = reportQueue;
        this.reportingServer = reportingServer;
        this.countDownLatch = countDownLatch;
    }

    /**
     * Executes until the {@code reportTransaction()} method signals to terminate
     */
    @Override
    public void run() {
        logger.info("Started");
        while (true) {
            if (reportTransaction() > 0) break;
        }
        logger.info("Finished");
    }

    /**
     * Report a transaction to the reporting server
     * @return {@code 0} if reporting is not finished or {@code > 0} if otherwise
     */
    private int reportTransaction() {
        TransactionReport txReport;
        try {
            txReport = reportQueue.poll(100, TimeUnit.MILLISECONDS);
            // If all TransactionProcessor instances have indicated completion and queue is empty, then signal the
            // reporting is finished to the caller
            if (txReport == null) {
                return countDownLatch.getCount() == 0 ? 1 : 0;
            }
        } catch (InterruptedException e) {
            logger.error("Thread was interrupted while waiting for transaction reports");
            Thread.currentThread().interrupt();
            return 2; // Signal the intention of termination to the caller
        }

        reportingServer.reportActivity(txReport.accountId(), txReport.instant(), txReport.amount(), txReport.balance());
        return 0;
    }
}
