package com.barrenjoey.java.bank.model;

import java.util.NoSuchElementException;

public interface Bank {

    /**
     * Retrieve the bank account with the {@code accountId} provided.
     * The account is always in a consistent state, i.e., its entries correspond to its balance.
     * @param accountId
     * @return bank account with the {@code accountId}
     * @throws NoSuchElementException if a bank account with the {@code accountId} is not available
     */
    BankAccount getAccountById(int accountId) throws NoSuchElementException;

    /**
     * If present, retrieve the bank account with the {@code accountId} or create a new bank account with the
     * {@code accountId} provided. This method is to be used by the {@code TransactionProcessor}.
     * @param accountId
     * @return bank account with the {@code accountId}
     */
    BankAccount getOrCreateAccount(int accountId);
}
