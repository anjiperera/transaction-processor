package com.barrenjoey.java.bank.model;

import java.time.Instant;

/**
 * AccountEntry Record
 * @param accountId The account id the transaction report corresponds to
 * @param action Action of the transaction (Deposit or Withdraw)
 * @param amount The amount of the transaction
 * @param instant Timestamp of the transaction
 */
public record AccountEntry(int accountId, Action action, double amount, Instant instant) {
    public enum Action {
        DEPOSIT,
        WITHDRAW
    }

    /**
     * A token to indicate the end of an account entries queue
     */
    public static final AccountEntry EOQ_TOKEN = new AccountEntry(0, null, 0, null);
}
