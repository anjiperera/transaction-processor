package com.barrenjoey.java.bank.model;

import java.time.Instant;

/**
 * Transaction Report record
 * @param accountId The account id the transaction report corresponds to
 * @param instant Timestamp of the transaction
 * @param amount The amount of the transaction
 * @param balance The balance of the account post application of the activity
 */
public record TransactionReport(int accountId, Instant instant, double amount, double balance) {}
