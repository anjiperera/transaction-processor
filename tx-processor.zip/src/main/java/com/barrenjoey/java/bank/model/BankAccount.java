package com.barrenjoey.java.bank.model;

public interface BankAccount extends Cloneable{
    /**
     * Calculate the new balance of the account after the deposit
     * @param depositAmount
     * @return the updated balance
     * @throws IllegalArgumentException if {@code depositAmount} is negative
     */
    double deposit(double depositAmount) throws IllegalArgumentException;

    /**
     * Calculate the new balance of the account after the withdrawal
     * @param withdrawalAmount
     * @return the updated balance
     * @throws IllegalArgumentException if {@code withdrawalAmount} is negative
     */
    double withdraw(double withdrawalAmount) throws IllegalArgumentException;

    /**
     * Get the current balance of the account
     * @return the balance
     */
    double getBalance();

    /**
     * Return the individual account entries in the order they were applied
     * @return the entries
     */
    AccountEntry[] entries();

    /**
     * Update the balance and entries attributes of the account in a thread-safe manner.
     * Implementations of this method should ensure thread-safety, e.g., synchronized.
     * All account updates should use this method, e.g., {@code TransactionProcessor}.
     * @param newBalance
     * @param newEntry
     */
    void updateAccount(double newBalance, AccountEntry newEntry);

    /**
     * Create a deep-copy clone of {@code this} in a thread-safe manner.
     * Implementations of this method should ensure thread-safety, e.g., synchronized.
     * This method should be used when a snapshot of the bank account object is required.
     * @return A deep-copy clone of {@code this}
     */
    BankAccount clone();
}
