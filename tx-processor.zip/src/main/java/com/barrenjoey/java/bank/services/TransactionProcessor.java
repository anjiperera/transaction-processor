package com.barrenjoey.java.bank.services;

import com.barrenjoey.java.bank.model.AccountEntry;
import com.barrenjoey.java.bank.model.Bank;
import com.barrenjoey.java.bank.model.BankAccount;
import com.barrenjoey.java.bank.model.TransactionReport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;

/**
 * This class is responsible for processing the account entries from the Entry Queue
 */
public class TransactionProcessor implements Runnable {

    private static final Logger logger = LoggerFactory.getLogger(TransactionProcessor.class);

    /**
     * Input queue with account entries
     */
    private BlockingQueue<AccountEntry> entryQueue;
    /**
     * An instance of the Bank
     */
    private Bank bank;
    /**
     * Output queue with transaction reports
     */
    private BlockingQueue<TransactionReport> reportQueue;
    /**
     * A shared {@code CountDownLatch} to indicate the end of the {@code TransactionProcessor} instances to
     * {@code TransactionReporters}
     */
    private CountDownLatch countDownLatch;

    public TransactionProcessor(BlockingQueue<AccountEntry> entryQueue,
                                Bank bank,
                                BlockingQueue<TransactionReport> reportQueue,
                                CountDownLatch countDownLatch) {
        this.entryQueue = entryQueue;
        this.bank = bank;
        this.reportQueue = reportQueue;
        this.countDownLatch = countDownLatch;
    }

    /**
     * Executes until the {@code processTransaction()} method signals to terminate
     */
    @Override
    public void run() {
        logger.info("Started");
        while (true) {
            if (processTransaction() > 0) {
                // Indicate the end of this TransactionProcessor instance to the TransactionReporter instances
                countDownLatch.countDown();
                break;
            }
        }
        logger.info("Finished");
    }

    /**
     * Process a transaction (read an account entry -> update the bank account -> create and push the transaction report)
     * @return {@code 0} if processing is not finished or {@code > 0} if otherwise
     */
    private int processTransaction() {
        AccountEntry accountEntry;
        try {
            accountEntry = entryQueue.take();
        } catch (InterruptedException e) {
            logger.error("Thread was interrupted while waiting for account entries");
            Thread.currentThread().interrupt();
            return 2; // Signal the intention of termination to the caller
        }

        // if the end of the queue is indicated by the producer, signal the processing is finished to the caller
        if (accountEntry.equals(AccountEntry.EOQ_TOKEN)) return 1;

        // update the corresponding bank account and create a transaction report
        TransactionReport report;
        try {
            BankAccount account = bank.getOrCreateAccount(accountEntry.accountId());
            report = updateAccount(account, accountEntry);
        } catch (IllegalArgumentException exception) {
            logger.error("Account entry {} is discarded with the error: {}", accountEntry, exception.getMessage());
            return 0;
        }

        // create and push the transaction report to reporting queue
        try {
            reportQueue.put(report);
        } catch (InterruptedException e) {
            logger.error("Thread was interrupted while waiting to add a transaction report");
            Thread.currentThread().interrupt();
            return 2; // Signal the intention of termination to the caller
        }

        return 0;
    }

    /**
     * Update the bank account with the account entry and create a transaction report of the transaction
     * @param account
     * @param accountEntry
     * @return new {@code TransactionReport} instance if the update is successful
     * @throw {@code IllegalArgumentException} if the {@code AccountEntry} contains unsupported/illegal arguments
     */
    private TransactionReport updateAccount(BankAccount account, AccountEntry accountEntry) throws IllegalArgumentException {
        double newBalance = switch (accountEntry.action()) {
            case DEPOSIT -> account.deposit(accountEntry.amount());
            case WITHDRAW -> account.withdraw(accountEntry.amount());
            default -> throw new IllegalArgumentException(
                    String.format("Unsupported action on account: %s", accountEntry.action()));
        };

        account.updateAccount(newBalance, accountEntry);

        return new TransactionReport(accountEntry.accountId(), accountEntry.instant(), accountEntry.amount(), account.getBalance());
    }
}
