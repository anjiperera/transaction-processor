package com.barrenjoey.java.bank.services;

import com.barrenjoey.java.bank.model.AccountEntry;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

public class TransactionReaderTest {

    @Test
    void shouldReadEntriesInOrder() throws InterruptedException {
        // Setup and run the TransactionReader
        final int ENTRY_Q_BOUND = 10;
        Map<Integer, BlockingQueue<AccountEntry>> entryQueues = new HashMap<>();
        entryQueues.put(0, new LinkedBlockingQueue<>(ENTRY_Q_BOUND));
        TransactionReader transactionReader = new TransactionReader(entryQueues,
                "src/test/resources/inputs/reader",
                "transaction-log.");

        transactionReader.run();

        // Validate the account entries prepared by TransactionReader
        Queue<AccountEntry> expectedEntries = new LinkedList<>();
        expectedEntries.add(new AccountEntry(1, AccountEntry.Action.WITHDRAW, 100, null));
        expectedEntries.add(new AccountEntry(2, AccountEntry.Action.DEPOSIT, 200, null));
        expectedEntries.add(new AccountEntry(1, AccountEntry.Action.WITHDRAW, 150, null));
        expectedEntries.add(new AccountEntry(2, AccountEntry.Action.DEPOSIT, 25, null));
        expectedEntries.add(new AccountEntry(2, AccountEntry.Action.WITHDRAW, 250, null));
        expectedEntries.add(new AccountEntry(1, AccountEntry.Action.WITHDRAW, 180, null));
        expectedEntries.add(AccountEntry.EOQ_TOKEN); // End of queue token

        BlockingQueue<AccountEntry> actualEntries = entryQueues.get(0);

        assertEquals(expectedEntries.size(), actualEntries.size(), "Number of account entries are different");
        Instant previous = null;
        while (true) {
            AccountEntry expectedEntry = expectedEntries.poll();
            if (expectedEntry.equals(AccountEntry.EOQ_TOKEN)) break;

            AccountEntry actualEntry = actualEntries.poll(1, TimeUnit.SECONDS);
            checkAccountEntryEquals(expectedEntry, actualEntry);

            Instant current = actualEntry.instant();
            if (previous != null) {
                assertFalse(previous.isAfter(current), "The account entry has a timestamp older than the " +
                        "timestamp of the previous entry");
            }
            previous = current;
        }
    }

    @Test
    void shouldPlaceEntriesOfAnAccountInOnlyOneQueue() {
        // Setup and run the TransactionReader
        final int ENTRY_Q_BOUND = 10;
        Map<Integer, BlockingQueue<AccountEntry>> entryQueues = new HashMap<>();
        entryQueues.put(0, new LinkedBlockingQueue<>(ENTRY_Q_BOUND));
        entryQueues.put(1, new LinkedBlockingQueue<>(ENTRY_Q_BOUND));
        TransactionReader transactionReader = new TransactionReader(entryQueues,
                "src/test/resources/inputs/reader",
                "transaction-log.");

        transactionReader.run();

        // Validate the account entries prepared by TransactionReader
        Set<Integer> accountIdsIn0 = getAccountIdsInQueue(entryQueues.get(0));
        Set<Integer> accountIdsIn1 = getAccountIdsInQueue(entryQueues.get(1));

        checkAccountIdsAreExclusive(accountIdsIn0, accountIdsIn1);
    }

    private void checkAccountEntryEquals(AccountEntry expected, AccountEntry actual) {
        assertEquals(expected.accountId(), actual.accountId(), "Account Id mismatch");
        assertEquals(expected.action(), actual.action(), "Action mismatch");
        assertEquals(expected.amount(), actual.amount(), "Amount mismatch");
    }

    private Set<Integer> getAccountIdsInQueue(BlockingQueue<AccountEntry> entryQueue) {
        return entryQueue.stream()
                .filter(entry -> !entry.equals(AccountEntry.EOQ_TOKEN))
                .map(AccountEntry::accountId)
                .collect(Collectors.toSet());
    }

    private void checkAccountIdsAreExclusive(Set<Integer> ids0, Set<Integer> ids1) {
        ids0.forEach(id -> assertFalse(ids1.contains(id), String.format("Account Id %d is found in both queues", id)));
    }
}
