package com.barrenjoey.java.bank.services;

import com.barrenjoey.java.bank.model.AccountEntry;
import com.barrenjoey.java.bank.model.BankAccount;
import com.barrenjoey.java.bank.model.BankImpl;
import com.barrenjoey.java.bank.model.Bank;
import com.barrenjoey.java.bank.model.TransactionReport;
import com.barrenjoey.java.bank.services.utils.ExecutorServiceUtil;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TransactionProcessorTest {

    private List<AccountEntry> prepareInputEntries() {
        List<AccountEntry> inputEntries = new ArrayList<>();

        inputEntries.add(new AccountEntry(1, AccountEntry.Action.WITHDRAW, 100, Instant.now()));
        inputEntries.add(new AccountEntry(2, AccountEntry.Action.DEPOSIT, 200, Instant.now()));
        inputEntries.add(new AccountEntry(1, AccountEntry.Action.WITHDRAW, 150, Instant.now()));
        inputEntries.add(new AccountEntry(2, AccountEntry.Action.DEPOSIT, 25, Instant.now()));
        inputEntries.add(new AccountEntry(2, AccountEntry.Action.WITHDRAW, 250, Instant.now()));
        inputEntries.add(new AccountEntry(1, AccountEntry.Action.WITHDRAW, 180, Instant.now()));

        return inputEntries;
    }

    @Test
    void shouldKeepCorrectAccountsOnCompletion() {
        // Setup and run the TransactionProcessor
        final int ENTRY_Q_BOUND = 10;
        final int REPORT_Q_BOUND = 10;
        BlockingQueue<AccountEntry> entryQueue = new LinkedBlockingQueue<>(ENTRY_Q_BOUND);
        BlockingQueue<TransactionReport> reportQueue = new LinkedBlockingQueue<>(REPORT_Q_BOUND);
        Bank bank = new BankImpl();

        List<AccountEntry> inputEntries = prepareInputEntries();
        entryQueue.addAll(inputEntries);
        entryQueue.add(AccountEntry.EOQ_TOKEN); // End of Queue Token

        TransactionProcessor transactionProcessor = new TransactionProcessor(entryQueue, bank, reportQueue, new CountDownLatch(1));

        transactionProcessor.run();

        // Validate the bank accounts updated by the TransactionProcessor once it has finished
        BankAccount account1 = bank.getAccountById(1);
        assertEquals(-430, account1.getBalance(), 0.0001, "Account balance is not correct.");
        assertEquals(inputEntries.stream()
                .filter(accountEntry -> accountEntry.accountId() == 1)
                .collect(Collectors.toList()), Arrays.asList(account1.entries()), "Account entries mismatch.");

        BankAccount account2 = bank.getAccountById(2);
        assertEquals(-25, account2.getBalance(), 0.0001, "Account balance is not correct.");
        assertEquals(inputEntries.stream()
                .filter(accountEntry -> accountEntry.accountId() == 2)
                .collect(Collectors.toList()), Arrays.asList(account2.entries()), "Account entries mismatch.");
    }

    @Test
    void shouldKeepCorrectAccountsWhileProcessing() throws InterruptedException {
        // Setup and run the TransactionProcessor in a separate thread
        final int ENTRY_Q_BOUND = 10;
        final int REPORT_Q_BOUND = 10;
        BlockingQueue<AccountEntry> entryQueue = new LinkedBlockingQueue<>(ENTRY_Q_BOUND);
        BlockingQueue<TransactionReport> reportQueue = new LinkedBlockingQueue<>(REPORT_Q_BOUND);
        Bank bank = new BankImpl();

        TransactionProcessor transactionProcessor = new TransactionProcessor(entryQueue, bank, reportQueue, new CountDownLatch(1));

        ExecutorService executorService = Executors.newFixedThreadPool(1);
        executorService.submit(transactionProcessor);

        // Step 1
        // Feed account entries to the account entry queue
        List<AccountEntry> inputEntries = new ArrayList<>();
        inputEntries.add(new AccountEntry(1, AccountEntry.Action.WITHDRAW, 100, Instant.now()));
        inputEntries.add(new AccountEntry(2, AccountEntry.Action.DEPOSIT, 200, Instant.now()));
        entryQueue.addAll(inputEntries);

        // Delay for the account entries to be processed by TransactionProcessor
        Thread.sleep(1000);

        // Validate the bank accounts at current state
        BankAccount account1 = bank.getAccountById(1);
        assertEquals(-100, account1.getBalance(), 0.0001, "Account balance is not correct.");
        assertEquals(inputEntries.stream()
                .filter(accountEntry -> accountEntry.accountId() == 1)
                .collect(Collectors.toList()), Arrays.asList(account1.entries()), "Account entries mismatch.");

        BankAccount account2 = bank.getAccountById(2);
        assertEquals(200, account2.getBalance(), 0.0001, "Account balance is not correct.");
        assertEquals(inputEntries.stream()
                .filter(accountEntry -> accountEntry.accountId() == 2)
                .collect(Collectors.toList()), Arrays.asList(account2.entries()), "Account entries mismatch.");

        // Step 2
        // Feed more account entries to the account entry queue
        inputEntries.add(new AccountEntry(1, AccountEntry.Action.WITHDRAW, 150, Instant.now()));
        inputEntries.add(new AccountEntry(2, AccountEntry.Action.DEPOSIT, 25, Instant.now()));
        entryQueue.addAll(inputEntries.subList(2, 4));

        // Delay for the new account entries to be processed by TransactionProcessor
        Thread.sleep(1000);

        // Validate the bank accounts at current state
        account1 = bank.getAccountById(1);
        assertEquals(-250, account1.getBalance(), 0.0001, "Account balance is not correct.");
        assertEquals(inputEntries.stream()
                .filter(accountEntry -> accountEntry.accountId() == 1)
                .collect(Collectors.toList()), Arrays.asList(account1.entries()), "Account entries mismatch.");

        account2 = bank.getAccountById(2);
        assertEquals(225, account2.getBalance(), 0.0001, "Account balance is not correct.");
        assertEquals(inputEntries.stream()
                .filter(accountEntry -> accountEntry.accountId() == 2)
                .collect(Collectors.toList()), Arrays.asList(account2.entries()), "Account entries mismatch.");

        // End the test
        ExecutorServiceUtil.shutDownThreads(executorService);
    }

    @Test
    void shouldKeepConsistentBankAccountsWhileProcessing() throws InterruptedException {
        // Setup and run the TransactionProcessor in a separate thread
        final int ENTRY_Q_BOUND = 100000;
        final int REPORT_Q_BOUND = 100000;
        BlockingQueue<AccountEntry> entryQueue = new LinkedBlockingQueue<>(ENTRY_Q_BOUND);
        BlockingQueue<TransactionReport> reportQueue = new LinkedBlockingQueue<>(REPORT_Q_BOUND);
        Bank bank = new BankImpl();

        TransactionProcessor transactionProcessor = new TransactionProcessor(entryQueue, bank, reportQueue, new CountDownLatch(1));

        ExecutorService executorService = Executors.newFixedThreadPool(2);
        executorService.submit(transactionProcessor);

        // Execute another thread that continuously feeds account entries into the account entry queue
        executorService.submit(() -> {
            while (true) {
                entryQueue.put(new AccountEntry(1, AccountEntry.Action.DEPOSIT, 1.0, Instant.now()));
                // Simulate a delay when feeding account entries, otherwise the report queue may become full before the test ends
                Thread.sleep(2);
            }
        });

        // Give some time for the TransactionProcessor to start processing the account entries
        Thread.sleep(100);

        // Validate the snapshots of the bank account for their consistency `n` times
        int n = 10;
        for (int i = 0; i < n; i++) {
            // Delay to create a gap between snapshot readings
            Thread.sleep(5);
            // Get a snapshot of the bank account
            BankAccount account = bank.getAccountById(1);
            double balanceByEntries = calculateBalanceByEntries(List.of(account.entries()));
            assertEquals(account.getBalance(), balanceByEntries, "Account entries do not sum up the balance.");
        }

        // End the test
        ExecutorServiceUtil.shutDownThreads(executorService);
    }

    @Test
    void shouldReportAllTransactions() {
        // Setup and run the TransactionProcessor
        final int ENTRY_Q_BOUND = 10;
        final int REPORT_Q_BOUND = 10;
        BlockingQueue<AccountEntry> entryQueue = new LinkedBlockingQueue<>(ENTRY_Q_BOUND);
        BlockingQueue<TransactionReport> reportQueue = new LinkedBlockingQueue<>(REPORT_Q_BOUND);
        Bank bank = new BankImpl();

        List<AccountEntry> inputEntries = prepareInputEntries();
        entryQueue.addAll(inputEntries);
        entryQueue.add(AccountEntry.EOQ_TOKEN); // End of Queue Token

        TransactionProcessor transactionProcessor = new TransactionProcessor(entryQueue, bank, reportQueue, new CountDownLatch(1));

        transactionProcessor.run();

        // Validate the transaction reports prepared by TransactionProcessor
        List<TransactionReport> expected = new ArrayList<>();
        int[] expectedBalances = {-100, 200, -250, 225, -25, -430};
        AtomicInteger i = new AtomicInteger();
        inputEntries.forEach(inputEntry -> {
            expected.add(new TransactionReport(inputEntry.accountId(),
                    inputEntry.instant(),
                    inputEntry.amount(),
                    expectedBalances[i.getAndIncrement()]));
        });

        assertEquals(expected, reportQueue.stream().toList(), "Transaction reports mismatch.");
    }

    private double calculateBalanceByEntries(List<AccountEntry> entries) {
        final double[] balance = {0};
        entries.forEach(entry -> {
            switch (entry.action()) {
                case DEPOSIT:
                    balance[0] += entry.amount();
                    break;
                case WITHDRAW:
                    balance[0] -= entry.amount();
                    break;
            }
        });
        return balance[0];
    }
}
