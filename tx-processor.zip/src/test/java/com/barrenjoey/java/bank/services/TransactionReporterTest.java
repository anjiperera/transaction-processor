package com.barrenjoey.java.bank.services;

import com.barrenjoey.java.bank.external.ReportingServer;
import com.barrenjoey.java.bank.model.TransactionReport;
import com.barrenjoey.java.bank.services.utils.ExecutorServiceUtil;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.invocation.Invocation;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

public class TransactionReporterTest {

    @Test
    void shouldSendReportsToServer() {
        // Setup and run the TransactionReporter
        final int REPORT_Q_BOUND = 10;
        BlockingQueue<TransactionReport> reportQueue = new LinkedBlockingQueue<>(REPORT_Q_BOUND);
        ReportingServer mockServer = mock(ReportingServer.class);

        List<TransactionReport> txReports = new ArrayList<>();
        txReports.add(new TransactionReport(1, Instant.now(), 100, 100));

        reportQueue.addAll(txReports);

        CountDownLatch countDownLatch = new CountDownLatch(0); // Since the test is run on a single thread, we indicate
        // the TransactionReporter that the producers have already finished
        TransactionReporter transactionReporter = new TransactionReporter(reportQueue, mockServer, countDownLatch);

        transactionReporter.run();

        ArgumentCaptor<Integer> accountIdCaptor = ArgumentCaptor.forClass(Integer.class);
        ArgumentCaptor<Instant> instantCaptor = ArgumentCaptor.forClass(Instant.class);
        ArgumentCaptor<Double> amountCaptor = ArgumentCaptor.forClass(Double.class);
        ArgumentCaptor<Double> balanceCaptor = ArgumentCaptor.forClass(Double.class);

        verify(mockServer).reportActivity(
                accountIdCaptor.capture(), instantCaptor.capture(), amountCaptor.capture(), balanceCaptor.capture());
        assertEquals(txReports.get(0).accountId(), accountIdCaptor.getValue(), "Account Id mismatch");
        assertEquals(txReports.get(0).instant(), instantCaptor.getValue(), "Timestamp mismatch");
        assertEquals(txReports.get(0).amount(), amountCaptor.getValue(), 0.0001, "Amount mismatch");
        assertEquals(txReports.get(0).balance(), balanceCaptor.getValue(), 0.0001, "Balance mismatch");

        assertEquals(0, reportQueue.size(), "Transaction reports queue is not empty");
    }

    @Test
    void shouldSendReportExactlyOnce() throws InterruptedException {
        // Setup and run two TransactionReporters
        final int REPORT_Q_BOUND = 10;
        BlockingQueue<TransactionReport> reportQueue = new LinkedBlockingQueue<>(REPORT_Q_BOUND);
        ReportingServer mockServer = mock(ReportingServer.class);

        CountDownLatch countDownLatch = new CountDownLatch(1);
        TransactionReporter reporter1 = new TransactionReporter(reportQueue, mockServer, countDownLatch);
        TransactionReporter reporter2 = new TransactionReporter(reportQueue, mockServer, countDownLatch);

        ExecutorService executorService = Executors.newFixedThreadPool(2);
        executorService.submit(reporter1);
        executorService.submit(reporter2);

        // Feed transaction reports to the reports queue
        List<TransactionReport> txReports = new ArrayList<>();
        txReports.add(new TransactionReport(1, Instant.now(), 100, 100));
        txReports.add(new TransactionReport(2, Instant.now(), 150, 150));
        reportQueue.addAll(txReports);

        // Delay for the transaction reports to be reported by TransactionReporters
        Thread.sleep(1000);

        // Validate the transaction reports sent to the reporting server
        ArgumentCaptor<Integer> accountIdCaptor = ArgumentCaptor.forClass(Integer.class);
        ArgumentCaptor<Instant> instantCaptor = ArgumentCaptor.forClass(Instant.class);
        ArgumentCaptor<Double> amountCaptor = ArgumentCaptor.forClass(Double.class);
        ArgumentCaptor<Double> balanceCaptor = ArgumentCaptor.forClass(Double.class);

        // Validate the number of times the ReportingServer is called
        Collection<Invocation> invocations = mockingDetails(mockServer).getInvocations();
        long numInvocations = invocations.stream()
                .filter(invocation -> "reportActivity".equals(invocation.getMethod().getName()))
                .count();
        assertEquals(txReports.size(), numInvocations, "ReportingServer was called more or less times than " +
                "the number of transaction reports");

        // Validate the transaction reports sent
        verify(mockServer, times((int) numInvocations)).reportActivity(
                accountIdCaptor.capture(), instantCaptor.capture(), amountCaptor.capture(), balanceCaptor.capture());

        Set<TransactionReport> actualOutputs = new HashSet<>();
        for (int i = 0; i < numInvocations; i++) {
            actualOutputs.add(new TransactionReport(accountIdCaptor.getAllValues().get(i),
                    instantCaptor.getAllValues().get(i),
                    amountCaptor.getAllValues().get(i),
                    balanceCaptor.getAllValues().get(i)));
        }

        Set<TransactionReport> expectedOutputs = new HashSet<>(txReports);

        expectedOutputs.forEach(expectedOutput -> {
            assertTrue(actualOutputs.contains(expectedOutput),
                    "Transaction report is not reported to the reporting server");
        });

        // End the test
        ExecutorServiceUtil.shutDownThreads(executorService);
    }
}
